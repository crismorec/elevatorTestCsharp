﻿using ElevatorSystem.Models;
using ElevatorSystem.Services;

namespace unitTestElevator
{
    [TestFixture]
    public class ElevatorTests
    {
        private SystemConfiguration _config;

        [SetUp]
        public void Setup()
        {
            _config = new SystemConfiguration
            {
                MinFloor = 1,
                MaxFloor = 10,
                MoveTimeMs = 1, // More fast for testing
                DoorTimeMs = 1
            };
        }

        #region Edge Cases & Data Validation

        [Test]
        [TestCase(11)]
        [TestCase(100)]
        [TestCase(208)] // Specific bug from previous candidate
        [TestCase(int.MaxValue)]
        public void AddDestination_ShouldRejectFloorsAboveMax(int invalidFloor)
        {
            var elevator = new ElevatorService(1, _config);
            elevator.AddDestination(invalidFloor);
            Assert.That(elevator.GetPending(), Is.EqualTo(""), "Should not accept floors higher than MaxFloor");
        }

        [Test]
        [TestCase(0)]
        [TestCase(-1)]
        [TestCase(-120)]
        [TestCase(int.MinValue)]
        public void AddDestination_ShouldRejectFloorsBelowMin(int invalidFloor)
        {
            var elevator = new ElevatorService(1, _config);
            elevator.AddDestination(invalidFloor);
            Assert.That(elevator.GetPending(), Is.EqualTo(""), "Should not accept floors lower than MinFloor");
        }

        [Test]
        public void AddDestination_ShouldHandleDuplicateEntries()
        {
            var elevator = new ElevatorService(1, _config);
            // Act: Adding same floor multiple times
            elevator.AddDestination(5);
            elevator.AddDestination(5);
            elevator.AddDestination(5);

            // Assert: SortedSet should handle duplicates internally
            var pending = elevator.GetPending().Split(',');
            Assert.That(pending.Length, Is.EqualTo(1), "Should only contain the floor once");
        }

        #endregion

        #region State & Logic Verification

        [Test]
        public void Elevator_InitialStatus_IsReadyAndFirstFloor()
        {
            var elevator = new ElevatorService(1, _config);
            Assert.Multiple(() =>
            {
                Assert.That(elevator.CurrentFloor, Is.EqualTo(1));
                Assert.That(elevator.Status, Is.EqualTo(ElevatorStatus.Ready));
            });
        }

        [Test]
        public void GetPending_ShouldReturnSortedFloors()
        {
            var elevator = new ElevatorService(1, _config);
            // Act: Adding floors in random order
            elevator.AddDestination(9);
            elevator.AddDestination(2);
            elevator.AddDestination(5);

            // Assert: Should be returned in order 2,5,9
            Assert.That(elevator.GetPending(), Is.EqualTo("2,5,9"));
        }

        #endregion

        #region System Manager & Concurrency

        [Test]
        public void Dispatcher_ShouldAssignToClosestElevator()
        {
            var manager = new SystemManager(_config);
            // We simulate that elevator 1 is busy or far, but here all are at floor 1
            // Act: Calling floor 10
            manager.Dispatch(10, Direction.Up);

            // At least one elevator must have taken the task
            // This validates that the dispatch logic don't leave calls "hanging"
            Assert.DoesNotThrow(() => manager.Dispatch(1, Direction.Down));
        }

        #endregion

        #region Stress & Robustness

        [Test]
        public void StressTest_MultipleRapidCalls()
        {
            var elevator = new ElevatorService(1, _config);

            // Simulating 100 rapid calls to different valid floors
            for (int i = 0; i < 100; i++)
            {
                elevator.AddDestination((i % 10) + 1);
            }

            var pending = elevator.GetPending().Split(',');
            Assert.That(pending.Length, Is.AtMost(10), "Should manage the queue without memory leaks or crashes");
        }

        [Test]
        public void System_ShouldHandleCancellationGracefully()
        {
            var elevator = new ElevatorService(1, _config);
            var cts = new CancellationTokenSource();

            // Act: Start and immediately cancel
            var task = elevator.StartAsync(cts.Token);
            cts.Cancel();

            // Assert: Task should complete without throwing unhandled exception to the main thread
            Assert.DoesNotThrowAsync(async () => await task);
        }

        #endregion
    }
}