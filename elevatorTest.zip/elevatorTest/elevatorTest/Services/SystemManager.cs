﻿using ElevatorSystem.Models;

namespace ElevatorSystem.Services
{
    public class SystemManager
    {
        private readonly List<ElevatorService> _elevators;
        private readonly SystemConfiguration _config;

        public SystemManager(SystemConfiguration config)
        {
            _config = config;
            _elevators = Enumerable.Range(1, 4)
                .Select(i => new ElevatorService(i, _config))
                .ToList();
        }

        public void Dispatch(int floor, Direction dir)
        {
            // Optimization: find car that is not busy or is already going same way [cite: 28]
            var bestCar = _elevators
                .OrderBy(e => Math.Abs(e.CurrentFloor - floor))
                .FirstOrDefault(e => e.CurrentDirection == Direction.Idle || e.CurrentDirection == dir);

            bestCar?.AddDestination(floor);
        }

        public void StartAll(CancellationToken ct) => _elevators.ForEach(e => _ = e.StartAsync(ct));

        public void Render()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("======= ELEVATOR MONITOR - Cristhian Moreno =======");
            Console.WriteLine($"STATUS: ACTIVE | TIME: {DateTime.Now:HH:mm:ss}");
            Console.WriteLine("====================================================");
            foreach (var e in _elevators)
            {
                string state = e.Status == ElevatorStatus.Moving ? $"MOVING {e.CurrentDirection}" : e.Status.ToString();
                Console.WriteLine($"ELEVATOR {e.Id}: Floor {e.CurrentFloor} | {state} | Queue: [{e.GetPending()}]");
            }
            Console.WriteLine("====================================================");
            Console.WriteLine("> Press Ctrl+C for system shutdown.");
            Console.ResetColor();
        }
    }
}