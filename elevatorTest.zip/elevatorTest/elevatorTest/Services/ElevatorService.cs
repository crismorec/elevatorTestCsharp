﻿using ElevatorSystem.Abstractions;
using ElevatorSystem.Models;

namespace ElevatorSystem.Services
{
    public class ElevatorService : IElevator
    {
        public int Id { get; }
        public int CurrentFloor { get; private set; } = 1;
        public Direction CurrentDirection { get; private set; } = Direction.Idle;
        public ElevatorStatus Status { get; private set; } = ElevatorStatus.Ready;

        private readonly SortedSet<int> _destinations = new();
        private readonly SystemConfiguration _config;

        public ElevatorService(int id, SystemConfiguration config)
        {
            Id = id;
            _config = config;
        }

        public void AddDestination(int floor)
        {
            // Security: check limits for avoid floor -120 or 208 errors
            if (floor >= _config.MinFloor && floor <= _config.MaxFloor)
            {
                lock (_destinations) { _destinations.Add(floor); }
            }
        }

        public async Task StartAsync(CancellationToken ct)
        {
            while (!ct.IsCancellationRequested)
            {
                try
                {
                    bool hasTargets;
                    lock (_destinations) { hasTargets = _destinations.Any(); }

                    if (!hasTargets)
                    {
                        CurrentDirection = Direction.Idle;
                        Status = ElevatorStatus.Ready;
                        await Task.Delay(500, ct);
                        continue;
                    }

                    if (_destinations.Contains(CurrentFloor))
                    {
                        await OpenDoorsAsync(ct);
                    }
                    else
                    {
                        UpdateDirection();
                        await MoveAsync(ct);
                    }
                }
                catch (OperationCanceledException) { break; }
                catch (Exception ex)
                {
                    // Global handle for service stability in prod environment
                    Console.WriteLine($"[ERROR] Elevator {Id} critical fail: {ex.Message}");
                    await Task.Delay(2000, ct);
                }
            }
        }

        private void UpdateDirection()
        {
            lock (_destinations)
            {
                if (!_destinations.Any()) return;

                int firstTarget = _destinations.First();
                // Logic for "No Yo-Yoing": keep going until no more stops in current way [cite: 12]
                if (CurrentDirection == Direction.Idle)
                {
                    CurrentDirection = firstTarget > CurrentFloor ? Direction.Up : Direction.Down;
                }
                else if (CurrentDirection == Direction.Up && !_destinations.Any(f => f > CurrentFloor))
                {
                    CurrentDirection = Direction.Down;
                }
                else if (CurrentDirection == Direction.Down && !_destinations.Any(f => f < CurrentFloor))
                {
                    CurrentDirection = Direction.Up;
                }
            }
        }

        private async Task MoveAsync(CancellationToken ct)
        {
            Status = ElevatorStatus.Moving;
            await Task.Delay(_config.MoveTimeMs, ct);

            if (CurrentDirection == Direction.Up && CurrentFloor < _config.MaxFloor)
                CurrentFloor++;
            else if (CurrentDirection == Direction.Down && CurrentFloor > _config.MinFloor)
                CurrentFloor--;
        }

        private async Task OpenDoorsAsync(CancellationToken ct)
        {
            Status = ElevatorStatus.DoorsOpen;
            await Task.Delay(_config.DoorTimeMs, ct);
            lock (_destinations) { _destinations.Remove(CurrentFloor); }
            Status = ElevatorStatus.Ready;
        }

        public string GetPending() => string.Join(",", _destinations);
    }
}