﻿namespace ElevatorSystem.Models
{
    public enum Direction { Idle, Up, Down }
    public enum ElevatorStatus { Ready, Moving, DoorsOpen }

    public class SystemConfiguration
    {
        public int MinFloor { get; set; } = 1;
        public int MaxFloor { get; set; } = 10;
        public int MoveTimeMs { get; set; } = 10000;
        public int DoorTimeMs { get; set; } = 10000;
    }
}