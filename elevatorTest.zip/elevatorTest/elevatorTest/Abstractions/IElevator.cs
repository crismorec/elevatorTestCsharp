﻿namespace ElevatorSystem.Abstractions
{
    public interface IElevator
    {
        int Id { get; }
        int CurrentFloor { get; }
        void AddDestination(int floor);
        Task StartAsync(CancellationToken ct);
    }
}